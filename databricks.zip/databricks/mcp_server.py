"""
Databricks MCP Server - Data Analytics & ML Platform
Execute SQL queries, run notebooks, manage clusters, and access Delta Lake
"""

from fastapi import FastAPI
from pydantic import BaseModel
import httpx
import json
import os
import asyncio
from typing import Dict, Any, List
from dotenv import load_dotenv

load_dotenv()

app = FastAPI(title="Databricks MCP Server")

# Databricks API configuration
DATABRICKS_HOST = os.getenv("DATABRICKS_HOST")
DATABRICKS_TOKEN = os.getenv("DATABRICKS_TOKEN")
DATABRICKS_CLUSTER_ID = os.getenv("DATABRICKS_CLUSTER_ID", "")

class ToolRequest(BaseModel):
    tool_name: str
    arguments: Dict[str, Any]

class Tool(BaseModel):
    name: str
    description: str
    inputSchema: Dict[str, Any]

def get_headers():
    """Get authorization headers for Databricks API"""
    return {
        "Authorization": f"Bearer {DATABRICKS_TOKEN}",
        "Content-Type": "application/json"
    }

@app.get("/")
async def root():
    return {
        "message": "Databricks MCP Server",
        "endpoints": {"/tools": "List tools", "/execute": "Execute tool", "/health": "Health check"}
    }

@app.get("/tools")
async def list_tools() -> List[Tool]:
    """List all available tools"""
    return [
        Tool(
            name="execute_sql",
            description="Execute SQL query on Databricks",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "SQL query to execute"}
                },
                "required": ["query"]
            }
        ),
        Tool(
            name="list_databases",
            description="List all databases/schemas in Databricks",
            inputSchema={"type": "object", "properties": {}, "required": []}
        ),
        Tool(
            name="list_tables",
            description="List all tables in a database/schema",
            inputSchema={
                "type": "object",
                "properties": {
                    "schema": {"type": "string", "description": "Schema name", "default": "default"}
                },
                "required": []
            }
        ),
        Tool(
            name="get_table_schema",
            description="Get schema/columns of a table",
            inputSchema={
                "type": "object",
                "properties": {
                    "table_name": {"type": "string", "description": "Table name"},
                    "schema": {"type": "string", "description": "Schema name", "default": "default"}
                },
                "required": ["table_name"]
            }
        ),
        Tool(
            name="list_clusters",
            description="List all available Databricks clusters",
            inputSchema={"type": "object", "properties": {}, "required": []}
        ),
        Tool(
            name="get_cluster_status",
            description="Get status of a cluster",
            inputSchema={
                "type": "object",
                "properties": {
                    "cluster_id": {"type": "string", "description": "Cluster ID"}
                },
                "required": []
            }
        ),
        Tool(
            name="start_cluster",
            description="Start a stopped cluster",
            inputSchema={
                "type": "object",
                "properties": {
                    "cluster_id": {"type": "string", "description": "Cluster ID"}
                },
                "required": []
            }
        ),
        Tool(
            name="list_jobs",
            description="List all Databricks jobs",
            inputSchema={
                "type": "object",
                "properties": {
                    "limit": {"type": "integer", "description": "Number of jobs", "default": 25}
                },
                "required": []
            }
        ),
        Tool(
            name="run_job",
            description="Trigger a job run",
            inputSchema={
                "type": "object",
                "properties": {
                    "job_id": {"type": "integer", "description": "Job ID to run"}
                },
                "required": ["job_id"]
            }
        ),
        Tool(
            name="run_notebook",
            description="Run a Databricks notebook",
            inputSchema={
                "type": "object",
                "properties": {
                    "notebook_path": {"type": "string", "description": "Path to notebook"}
                },
                "required": ["notebook_path"]
            }
        )
    ]

async def execute_sql_on_cluster(query: str, cluster_id: str = None):
    """Execute SQL on a cluster using context API"""
    if not cluster_id:
        cluster_id = DATABRICKS_CLUSTER_ID

    if not cluster_id:
        return {"error": "No cluster configured"}

    try:
        # Create execution context
        context_url = f"{DATABRICKS_HOST}/api/1.2/contexts/create"
        context_payload = {"clusterId": cluster_id, "language": "sql"}

        async with httpx.AsyncClient(timeout=30.0) as client:
            context_response = await client.post(context_url, headers=get_headers(), json=context_payload)
            context_response.raise_for_status()
            context_id = context_response.json().get("id")

            # Execute command
            command_url = f"{DATABRICKS_HOST}/api/1.2/commands/execute"
            command_payload = {
                "clusterId": cluster_id,
                "contextId": context_id,
                "language": "sql",
                "command": query
            }

            command_response = await client.post(command_url, headers=get_headers(), json=command_payload)
            command_response.raise_for_status()
            command_id = command_response.json().get("id")

            # Poll for results
            status_url = f"{DATABRICKS_HOST}/api/1.2/commands/status"
            for _ in range(30):
                await asyncio.sleep(1)
                status_response = await client.get(
                    f"{status_url}?clusterId={cluster_id}&contextId={context_id}&commandId={command_id}",
                    headers=get_headers()
                )
                status_data = status_response.json()

                if status_data.get("status") == "Finished":
                    results = status_data.get("results", {})
                    data = results.get("data", [])
                    schema = results.get("schema", [])
                    columns = [col.get("name", f"col_{i}") for i, col in enumerate(schema)]

                    return {
                        "status": "success",
                        "columns": columns,
                        "rows": data if data else [],
                        "total_rows": len(data) if data else 0
                    }
                elif status_data.get("status") in ["Error", "Cancelled"]:
                    return {"error": status_data.get("results", {}).get("cause", "Command failed")}

            return {"error": "Command timed out"}

    except Exception as e:
        return {"error": str(e)}

async def execute_sql(query: str):
    """Execute SQL query"""
    if not DATABRICKS_HOST or not DATABRICKS_TOKEN:
        return {"error": "Databricks credentials not configured"}

    try:
        # Try SQL warehouse first
        url = f"{DATABRICKS_HOST}/api/2.0/sql/statements"
        payload = {
            "statement": query,
            "warehouse_id": os.getenv("DATABRICKS_WAREHOUSE_ID", ""),
            "wait_timeout": "30s"
        }

        async with httpx.AsyncClient(timeout=60.0) as client:
            response = await client.post(url, headers=get_headers(), json=payload)

            if response.status_code == 200:
                data = response.json()
                if data.get("status", {}).get("state") == "SUCCEEDED":
                    result = data.get("result", {})
                    columns = [col["name"] for col in result.get("data_array", [])]
                    rows = result.get("data_array", [])
                    return {
                        "status": "success",
                        "columns": columns,
                        "rows": rows[:100],
                        "total_rows": len(rows)
                    }

        # Fall back to cluster
        return await execute_sql_on_cluster(query)

    except Exception as e:
        return await execute_sql_on_cluster(query)

async def list_databases():
    """List databases"""
    query = "SHOW DATABASES"
    result = await execute_sql(query)

    if "error" in result:
        return result

    databases = [row[0] if isinstance(row, list) else row for row in result.get("rows", [])]
    return {"databases": databases, "count": len(databases)}

async def list_tables(schema: str = "default"):
    """List tables in schema"""
    query = f"SHOW TABLES IN {schema}"
    result = await execute_sql(query)

    if "error" in result:
        return result

    tables = []
    for row in result.get("rows", []):
        if isinstance(row, list) and len(row) > 1:
            tables.append(row[1])

    return {"schema": schema, "tables": tables, "count": len(tables)}

async def get_table_schema(table_name: str, schema: str = "default"):
    """Get table schema"""
    query = f"DESCRIBE TABLE {schema}.{table_name}"
    result = await execute_sql(query)

    if "error" in result:
        return result

    columns = []
    for row in result.get("rows", []):
        if row[0] and not row[0].startswith("#"):
            columns.append({"name": row[0], "type": row[1]})

    return {"table": table_name, "columns": columns, "count": len(columns)}

async def list_clusters():
    """List clusters"""
    if not DATABRICKS_HOST or not DATABRICKS_TOKEN:
        return {"error": "Databricks credentials not configured"}

    try:
        url = f"{DATABRICKS_HOST}/api/2.0/clusters/list"
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(url, headers=get_headers())
            response.raise_for_status()
            data = response.json()

        clusters = []
        for cluster in data.get("clusters", []):
            clusters.append({
                "cluster_id": cluster.get("cluster_id"),
                "cluster_name": cluster.get("cluster_name"),
                "state": cluster.get("state")
            })

        return {"clusters": clusters, "count": len(clusters)}

    except Exception as e:
        return {"error": str(e)}

async def get_cluster_status(cluster_id: str = ""):
    """Get cluster status"""
    cluster_id = cluster_id or DATABRICKS_CLUSTER_ID
    if not cluster_id:
        return {"error": "No cluster_id provided"}

    try:
        url = f"{DATABRICKS_HOST}/api/2.0/clusters/get"
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(url, headers=get_headers(), params={"cluster_id": cluster_id})
            response.raise_for_status()
            data = response.json()

        return {
            "cluster_id": data.get("cluster_id"),
            "cluster_name": data.get("cluster_name"),
            "state": data.get("state"),
            "state_message": data.get("state_message", "")
        }

    except Exception as e:
        return {"error": str(e)}

async def start_cluster(cluster_id: str = ""):
    """Start cluster"""
    cluster_id = cluster_id or DATABRICKS_CLUSTER_ID
    if not cluster_id:
        return {"error": "No cluster_id provided"}

    try:
        url = f"{DATABRICKS_HOST}/api/2.0/clusters/start"
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(url, headers=get_headers(), json={"cluster_id": cluster_id})
            response.raise_for_status()

        return {"status": "starting", "cluster_id": cluster_id}

    except Exception as e:
        return {"error": str(e)}

async def list_jobs(limit: int = 25):
    """List jobs"""
    try:
        url = f"{DATABRICKS_HOST}/api/2.1/jobs/list"
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(url, headers=get_headers(), params={"limit": limit})
            response.raise_for_status()
            data = response.json()

        jobs = []
        for job in data.get("jobs", []):
            jobs.append({
                "job_id": job.get("job_id"),
                "name": job.get("settings", {}).get("name", "Unnamed")
            })

        return {"jobs": jobs, "count": len(jobs)}

    except Exception as e:
        return {"error": str(e)}

async def run_job(job_id: int):
    """Run job"""
    try:
        url = f"{DATABRICKS_HOST}/api/2.1/jobs/run-now"
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(url, headers=get_headers(), json={"job_id": job_id})
            response.raise_for_status()
            data = response.json()

        return {"status": "running", "job_id": job_id, "run_id": data.get("run_id")}

    except Exception as e:
        return {"error": str(e)}

async def run_notebook(notebook_path: str):
    """Run notebook"""
    try:
        url = f"{DATABRICKS_HOST}/api/2.1/jobs/runs/submit"
        payload = {
            "run_name": f"MCP Run: {notebook_path}",
            "tasks": [{
                "task_key": "notebook_task",
                "notebook_task": {"notebook_path": notebook_path},
                "existing_cluster_id": DATABRICKS_CLUSTER_ID
            }]
        }

        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(url, headers=get_headers(), json=payload)
            response.raise_for_status()
            data = response.json()

        return {"status": "submitted", "run_id": data.get("run_id"), "notebook_path": notebook_path}

    except Exception as e:
        return {"error": str(e)}

@app.post("/execute")
async def execute_tool(request: ToolRequest):
    """Execute a tool"""
    try:
        if request.tool_name == "execute_sql":
            result = await execute_sql(request.arguments.get("query", ""))
        elif request.tool_name == "list_databases":
            result = await list_databases()
        elif request.tool_name == "list_tables":
            result = await list_tables(request.arguments.get("schema", "default"))
        elif request.tool_name == "get_table_schema":
            result = await get_table_schema(
                request.arguments.get("table_name", ""),
                request.arguments.get("schema", "default")
            )
        elif request.tool_name == "list_clusters":
            result = await list_clusters()
        elif request.tool_name == "get_cluster_status":
            result = await get_cluster_status(request.arguments.get("cluster_id", ""))
        elif request.tool_name == "start_cluster":
            result = await start_cluster(request.arguments.get("cluster_id", ""))
        elif request.tool_name == "list_jobs":
            result = await list_jobs(request.arguments.get("limit", 25))
        elif request.tool_name == "run_job":
            result = await run_job(request.arguments.get("job_id"))
        elif request.tool_name == "run_notebook":
            result = await run_notebook(request.arguments.get("notebook_path", ""))
        else:
            result = {"error": f"Unknown tool: {request.tool_name}"}

        return {"result": json.dumps(result, indent=2)}

    except Exception as e:
        return {"result": json.dumps({"error": str(e)})}

@app.get("/health")
async def health():
    """Health check"""
    return {
        "status": "healthy",
        "databricks_host": DATABRICKS_HOST if DATABRICKS_HOST else "Not configured",
        "cluster_id": DATABRICKS_CLUSTER_ID if DATABRICKS_CLUSTER_ID else "Not set"
    }

if __name__ == "__main__":
    import uvicorn
    print("=" * 50)
    print("Databricks MCP Server")
    print("=" * 50)
    print(f"Host: {DATABRICKS_HOST or 'Not configured'}")
    print(f"Token: {'Configured' if DATABRICKS_TOKEN else 'Missing'}")
    print(f"Cluster: {DATABRICKS_CLUSTER_ID or 'Not set'}")
    print("=" * 50)
    uvicorn.run(app, host="0.0.0.0", port=8099)
