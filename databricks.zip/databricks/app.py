#!/usr/bin/env python3
"""
Databricks Terminal Bot
AI-powered terminal interface for Databricks using MCP
"""

import os
import json
import httpx
from dotenv import load_dotenv
from langchain_openai import AzureChatOpenAI
from langchain.agents import AgentExecutor, create_openai_functions_agent
from langchain.tools import StructuredTool
from langchain.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain.memory import ConversationBufferMemory

load_dotenv()

# Configuration
MCP_SERVER_URL = os.getenv("MCP_DATABRICKS_URL", "http://localhost:8099")

# Initialize Azure OpenAI
llm = AzureChatOpenAI(
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
    deployment_name=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME"),
    temperature=0
)

def call_mcp_tool(tool_name: str, arguments: dict) -> str:
    """Call MCP server tool"""
    try:
        with httpx.Client(timeout=60.0) as client:
            response = client.post(
                f"{MCP_SERVER_URL}/execute",
                json={"tool_name": tool_name, "arguments": arguments}
            )
            response.raise_for_status()
            result = response.json()
            return result.get("result", json.dumps(result))
    except Exception as e:
        return json.dumps({"error": str(e)})

# Tool wrapper functions
def execute_sql_func(query: str) -> str:
    """Execute SQL query on Databricks"""
    return call_mcp_tool("execute_sql", {"query": query})

def list_databases_func() -> str:
    """List all databases in Databricks"""
    return call_mcp_tool("list_databases", {})

def list_tables_func(database_schema: str = "default") -> str:
    """List all tables in a database schema"""
    return call_mcp_tool("list_tables", {"schema": database_schema})

def get_table_schema_func(table_name: str, database_schema: str = "default") -> str:
    """Get columns of a table"""
    return call_mcp_tool("get_table_schema", {"table_name": table_name, "schema": database_schema})

def list_clusters_func() -> str:
    """List all Databricks clusters"""
    return call_mcp_tool("list_clusters", {})

def get_cluster_status_func(cluster_id: str = "") -> str:
    """Get status of a cluster"""
    return call_mcp_tool("get_cluster_status", {"cluster_id": cluster_id})

def start_cluster_func(cluster_id: str = "") -> str:
    """Start a stopped cluster"""
    return call_mcp_tool("start_cluster", {"cluster_id": cluster_id})

def list_jobs_func(limit: int = 25) -> str:
    """List all Databricks jobs"""
    return call_mcp_tool("list_jobs", {"limit": limit})

def run_job_func(job_id: int) -> str:
    """Run a Databricks job"""
    return call_mcp_tool("run_job", {"job_id": job_id})

def run_notebook_func(notebook_path: str) -> str:
    """Run a Databricks notebook"""
    return call_mcp_tool("run_notebook", {"notebook_path": notebook_path})

# Create tools
tools = [
    StructuredTool.from_function(
        func=execute_sql_func,
        name="execute_sql",
        description="Execute SQL query on Databricks. Use this for any data queries, SELECT, SHOW, etc."
    ),
    StructuredTool.from_function(
        func=list_databases_func,
        name="list_databases",
        description="List all databases/schemas in Databricks"
    ),
    StructuredTool.from_function(
        func=list_tables_func,
        name="list_tables",
        description="List all tables in a database/schema"
    ),
    StructuredTool.from_function(
        func=get_table_schema_func,
        name="get_table_schema",
        description="Get schema/columns of a table"
    ),
    StructuredTool.from_function(
        func=list_clusters_func,
        name="list_clusters",
        description="List all available Databricks clusters"
    ),
    StructuredTool.from_function(
        func=get_cluster_status_func,
        name="get_cluster_status",
        description="Get status of a cluster"
    ),
    StructuredTool.from_function(
        func=start_cluster_func,
        name="start_cluster",
        description="Start a stopped cluster"
    ),
    StructuredTool.from_function(
        func=list_jobs_func,
        name="list_jobs",
        description="List all Databricks jobs"
    ),
    StructuredTool.from_function(
        func=run_job_func,
        name="run_job",
        description="Run a Databricks job by ID"
    ),
    StructuredTool.from_function(
        func=run_notebook_func,
        name="run_notebook",
        description="Run a Databricks notebook"
    )
]

# Create agent prompt
prompt = ChatPromptTemplate.from_messages([
    ("system", """You are a Databricks assistant. You help users interact with their Databricks workspace.

You can:
- Execute SQL queries on Databricks
- List databases, tables, and get table schemas
- Manage clusters (list, status, start)
- List and run jobs
- Run notebooks

When users ask questions about data, first check available tables, then write and execute SQL queries.
Always provide clear, formatted responses with the results."""),
    MessagesPlaceholder(variable_name="chat_history"),
    ("human", "{input}"),
    MessagesPlaceholder(variable_name="agent_scratchpad")
])

# Create memory and agent
memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)
agent = create_openai_functions_agent(llm, tools, prompt)
agent_executor = AgentExecutor(agent=agent, tools=tools, memory=memory, verbose=False)

def check_mcp_server():
    """Check if MCP server is running"""
    try:
        with httpx.Client(timeout=5.0) as client:
            response = client.get(f"{MCP_SERVER_URL}/health")
            return response.status_code == 200
    except:
        return False

def main():
    """Main terminal interface"""
    print("=" * 60)
    print("  Databricks Terminal Bot")
    print("=" * 60)
    print()

    # Check MCP server
    if check_mcp_server():
        print("  MCP Server: Connected")
    else:
        print("  MCP Server: Not running!")
        print()
        print("  Start the MCP server first:")
        print("    python mcp_server.py")
        print()
        return

    print()
    print("  Commands:")
    print("    Type your question or command")
    print("    'quit' or 'exit' to quit")
    print("    'clear' to clear conversation history")
    print()
    print("=" * 60)
    print()

    while True:
        try:
            user_input = input("You: ").strip()

            if not user_input:
                continue

            if user_input.lower() in ['quit', 'exit', 'q']:
                print("\nGoodbye!")
                break

            if user_input.lower() == 'clear':
                memory.clear()
                print("\nConversation cleared.\n")
                continue

            print()
            print("Bot: ", end="", flush=True)

            try:
                response = agent_executor.invoke({"input": user_input})
                print(response.get("output", "No response"))
            except Exception as e:
                print(f"Error: {str(e)}")

            print()

        except KeyboardInterrupt:
            print("\n\nGoodbye!")
            break
        except EOFError:
            print("\n\nGoodbye!")
            break

if __name__ == "__main__":
    main()
